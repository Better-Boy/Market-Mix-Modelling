
# Introduction

*__"Half the money I spend on advertising is wasted; the trouble is I don't know which half."__* 
           
>    John Wanamaker, a marketing pioneer in late 1990s and early 20th century,is reputed to have made this statement and advertisers have been wrestling with the problem ever since.<br>

>    In early days,many companies found it difficult to quantify the impact of various advertising channels such as newspapers,television,radio etc on their products. Though there were certain methods adopted by these companies as a solution to the problem,those methods consisted more of naive approaches rather than sophisticated and reliable techniques. In late 1990s, things started to change and the art of marketing measurements became more matured due to the influence of econometric groups with advertising agencies finding better ways to gain insights from the complex array of marketing measurements which came to be known as Marketing Mix Modelling.

# What is MMM?

> Marketing Mix Modelling encompasses the method of statistical analysis such as regression on sales and marketing data to estimate the impact of various marketing tactics on sales and then predict the impact of future sets of tactics. It is also used to optimize the advertising mix and promotional tactics with respect to sales revenue or profit. Today, most brands and companies have embraced and are embracing these advanced measurement methodologies to determine the true impact of all interactions across all devices, channels, and campaign tactics. <br>
Nowadays,most companies have a strong econometric modelling foundation with slightly varying strategies depending on their requirements,products,external competition etc.

## Breaking the phrase "Market Mix Modelling"

> On breaking the phrase,we get three words i.e Marketing,Mix and Modelling.Let's explore these terms.
1. Marketing : This term corresponds to the understanding the market.
2. Mix : Mix here refers to how much importance should each P be given in the 4 P(Product,price,place and promotion)
3. Modelling : Modelling here refers to the optimization and building the model.

# Designing the right Marketing Mix:

The most creative & challenging step in marketing is designing the right marketing mix. The marketing mix is specific collection of actions & associated instruments employed by an organisation to stimulate acceptance of its ideas,products & services.

## Final Offer to the Customer:

The final offer made to the customer or consumer is dependent on the marketing manager of the firm 
where the following four steps are followed.
1. The firm (or the marketing manager chooses the product to meet the market demands.
2. The right distribution channel is used to make the product available.
3. An eye catching promotion is offered to the customer for the products.
4. Besides promotion,appropriate price is fixed agreed by the firm and customer.

## The 4 P

> A prominent marketer by name E.Jerome McCarthy proposed a four P classification in the year 1960,that has been widely used till date.
> The four Ps can be related to the customer as follows.
1. Product = Customer (or Consumer):
> The first marketing-mix element is the product, which refers to the offering or group of offerings to customers. Products can be physical or virtual. In the case of a physical product, such as a bike, a company will gather information about the desired features and benefits required by a target market. Before building the product, the marketer's role is to communicate customer requirements to the engineers who design the product. This is in contrast to past practice, when engineers designed a product based on their own preferences, or expertise and the marketers had to find suitable customers to buy this product. Contemporary thinking calls for products to be designed based on customer requirements but not solely on engineers' ideas.
> In contemporary industrialized societies, products go through life cycles: birth, growth, maturity, and decline or upgradation. This constant replacement of existing products with new or upgraded products has significant consequences for professional marketers. The development of new products involves all aspects of a business—production, finance, research and development, and even personnel administration and public relations.
> Nowadays, some of the products are the recycled version of the same product sold in the market. This also has an impact on the brand where the resources are reused for environmental purposes.
> Products are virtual in nature are the remote services offered by the company. For example, services offered by means of an API. Amazon Web Services offers virtualization service through it's cloud APIs.
2. Price :
> The second marketing-mix element is price. Ordinarily companies determine a price by gauging the competence level of the offer and then selecting a price that reflects how the market values its level of quality. However, marketers also are aware that price can send a message to a customer about the brand's reputation and product's presumed quality level. A BMW vehicle is generally considered to be a high-quality automobile. Therefore,BMW can command a high price in the market place. But, even if the brand could price its cars competitively with economy cars, it might not do so, knowing that the lower price might communicate lower quality. On the other hand, in order to gain market share, some companies have moved to “more for the same” or “the same for less” or "cheap and best" pricing, which means offering prices that are consistently lower than those of their competitors. This kind of discount pricing has caused firms in such industries as airlines and pharmaceuticals (which used to charge a price premium based on their past brand strength and reputation) to significantly reevaluate their marketing strategies.
3. Place :
> Place, or where the product is made available, is the third element of the marketing mix and is most commonly referred to as distribution. When a product moves along its path from producer to consumer, it is said to be following a channel of distribution. For example, the channel of distribution for many food products includes food-processing plants, warehouses, wholesalers, and supermarkets.
> By using this channel, a food manufacturer makes its products easily accessible by ensuring that they are in stores that are frequented by those in the target market. In another example, a mutual funds organization makes its investment products available by enlisting the assistance of brokerage houses and banks, which in turn establish relationships with particular customers. However, each channel participant can handle only a certain number of products: space at supermarkets is limited, and investment brokers can keep abreast of only a limited number of mutual funds. Because of this, some marketers may decide to skip steps in the channel and instead market directly to buyers through direct mail, telemarketing, door-to-door selling, shopping via television (a growing trend in the late 20th century), or factory outlets.
4. Promotion :
> Promotion, the fourth marketing-mix element, consists of several methods of communicating with and influencing customers. The major tools are sales force, advertising, sales promotion, and public relations.

  1. Sales force
    > Sales representatives are the most expensive means of promotion, because they require income, expenses, and supplementary benefits. Their ability to personalize the promotion process makes sales people most effective at selling complex goods, big-ticket items, and highly personal goods—forexample, those related to religion or insurance. Salespeople are trained to make presentations, answer objections, gain commitments to purchase, and manage account growth. Some companies have successfully reduced their sales-force costs by replacing certain functions (for example, finding new customers) with less expensive methods (such as direct mail and telemarketing).

  2. Advertising
     > Advertising includes all forms of paid, non personal communication and promotion of products, services, or ideas by a specified sponsor. Advertising appears in such media as print (newspapers, magazines, billboards, flyers) or broadcast (radio, television). Print advertisements typically consist of a picture, a headline, information about the product, and occasionally a response coupon. Broadcast advertisements consist of an audio or video narrative that can range from short 15-second spots to longer segments known as infomercials, which generally last 30or 60 minutes.

  3. Sales promotion
     > While advertising presents a reason to buy a product, sales promotion offers a short-term incentive to purchase. Sales promotions often attract brand switchers (those who are not loyal to a specific brand) who are looking primarily for low price and good value. Thus, especially in markets where brands are highly similar, sales promotions can cause a short-term increase in sales but little permanent gain in market share. Alternatively, in markets where brands are quite dissimilar, sales promotions can alter market shares more permanently. The use of promotions has risen considerably during the late 20th century. This is due to a number of factors within companies, including an increased sophistication in sales promotion techniques and greater pressure to increase sales. Several market factors also have fostered this increase, including a rise in the number of brands (especially similar ones) and a decrease in the efficiency of traditional advertising due to increasingly fractionated consumer markets.

  4. Public relations
      > Public relations in contrast to advertising and sales promotion, generally involves less commercialized modes of communication. Its primary purpose is to disseminate information and opinion to groups and individuals who have an actual or potential impact on a company's ability to achieve its objectives. In addition, public relations specialists are responsible for monitoring these individuals and groups and for maintaining good relationships with them. One of their key activities is to work with news and information media to ensure appropriate coverage of the company's activities and products. Public relations specialists create publicity by arranging press conferences, contests, meetings, and other events that will draw attention to a company's products or services. Another public relations responsibility is crisis management—that is, handling situations in which public awareness of a particular issue may dramatically and negatively impact the company's ability to achieve its goals. For example, when it was discovered that some bottles of Perrier sparkling water might have been tainted by a harmful chemical, Source Perrier, SA's public relations team had to ensure that the general consuming public did not thereafter automatically associate Perrier with tainted water. Other public relations activities include lobbying, advising management about public issues, and planning community events.


# Extension to 4 P:

There have been attempts to develop 'extended marketing mix' to better accomodate specific aspects of marketing mix.Booms and Bitner included three additional 'Ps' to accommodatetrends towards a service or knowledge based economy.They are
1. People
   > All people who directly or indirectly influence the perceived value of the product or service, including knowledge workers,employees, management and consumers.
2. Process
   > Procedures, mechanisms and flow of activities whichlead to an exchange of value.
3. Physical Evidence
   > The direct sensory experience of a product or service that allows a customer to measure whether he or she has received value. Examples might include the way a customer is treated by a staff member, or the length of time a customer has to wait, or the environment in which a product or service is delivered.

### Note:
1. The term 'marketing mix' however, does not imply that the 4P elements represent options.
2. They are not trade-offs but are fundamental marketing issues that always need to be addressed.
3. They are the fundamental actions that marketing requires whether determined explicitly or by default.


## Optimizing the marketing mix:
> By offering the product with combination of 4 P's,the product's popularity and the sales revenue of the company selling that product will gradually increase.
There are 2 optimizations that can be implemented.
1. Strategic Optimization : 
   > This comes into picture when there are large changes made to the weightage given to a particular P or a group of P's. For example,a large change in price from Rs.500 to Rs.1000 might have a profound effect on the sales revenue.Such kind of changes falls under this category.
2. Tactical Optimization :
   > This comes into picture when there is small changes made to the weightage given to a particular P or a group of P's. For example,considering the above example for Strategic Optimization,if the Price changes from Rs.500 to Rs.499,then these kinds of changes fall under Tachtical Optimization.

# Strengths and Weakness of MMM:

Though we consider market mix modelling as one of the sophisticated methods, it does have it's own strengths and weakness. Let's explore it.

## Strengths:
> A successfully implemented marketing mix model can provide the following benefits:
  1. It reflects on the past marketing decisions taken, by calculating return on investment (ROI).
  2. It helps to optimize the marketing mix for companies by forecasting the likely impact of changes to various marketing mix variables.
  3. It helps in finding the changes in business performance by isolating the impact of internal and external factors.

## Weakness:
> 
1. The focus on short-term sales can significantly under-value the importance of longer-term equity building activities
2. MMM used for media mix optimization, has a bias in favor of time-dependent media (such as Television) versus less time-dependent media (such as ads appearing in monthly magazines); biases can also occur when comparing broad-based media versus demographically targeted media.

 ## Working of MMM

Let's understand the working of MMM with an example.
Basically, MMM's are analysed and implemented with statiscal learning algorithms such as regression.

Many regression types are used in MMM for better accuracy and performance. Some of them are linear regression, multivariate regression etc.

Data set we will be working on for learning MMM is the data set used in the book 'Cutting-Edge Marketing Analytics: Real World Cases and Data Sets for Hands On Learning'. The data set is available to download from www.dmanalytics.org.


```python
import pandas as pd
import numpy as np
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt

%matplotlib inline
```


```python
data = pd.read_excel('MMM.xlsx')
```


```python
# Let's preview the data
print data.describe()
print data.columns
```

             Brand ID         Year     Absolut  Aristocrat      Barton  \
    count  263.000000   263.000000  263.000000  263.000000  263.000000   
    mean    12.596958  2001.695817    0.049430    0.049430    0.049430   
    std      7.654584     3.639093    0.217177    0.217177    0.217177   
    min      1.000000  1995.000000    0.000000    0.000000    0.000000   
    25%      6.000000  1999.000000    0.000000    0.000000    0.000000   
    50%     12.000000  2002.000000    0.000000    0.000000    0.000000   
    75%     18.000000  2005.000000    0.000000    0.000000    0.000000   
    max     31.000000  2007.000000    1.000000    1.000000    1.000000   
    
            Belvedere     Burnett      Chopin  Crystal Palac   Finlandia  \
    count  263.000000  263.000000  263.000000     263.000000  263.000000   
    mean     0.026616    0.041825    0.026616       0.049430    0.049430   
    std      0.161265    0.200571    0.161265       0.217177    0.217177   
    min      0.000000    0.000000    0.000000       0.000000    0.000000   
    25%      0.000000    0.000000    0.000000       0.000000    0.000000   
    50%      0.000000    0.000000    0.000000       0.000000    0.000000   
    75%      0.000000    0.000000    0.000000       0.000000    0.000000   
    max      1.000000    1.000000    1.000000       1.000000    1.000000   
    
               ...       LagTotalMinusSales     TierSales  OutsideTierSales  \
    count      ...               263.000000    263.000000        263.000000   
    mean       ...             62673.935361   9547.235741      53106.615970   
    std        ...              1548.346560   2917.310122       2259.775837   
    min        ...             55687.000000    846.000000      48358.000000   
    25%        ...             62459.000000   8151.500000      51863.000000   
    50%        ...             63204.000000  10605.000000      52335.000000   
    75%        ...             63616.000000  11209.000000      54570.000000   
    max        ...             64131.000000  15790.000000      59760.000000   
    
           LagTierSales  LagOutsideTierSales  Firstintro  Marketshare  \
    count    263.000000           263.000000  263.000000   263.000000   
    mean    9215.528517         53458.406844    0.015209     0.046972   
    std     2946.563257          2327.430916    0.122617     0.053831   
    min      697.000000         49806.000000    0.000000     0.001468   
    25%     7493.000000         51947.000000    0.000000     0.014762   
    50%    10400.000000         52419.000000    0.000000     0.029463   
    75%    11127.500000         55392.000000    0.000000     0.053087   
    max    14299.000000         59868.000000    1.000000     0.270477   
    
           LagMktshare      YearID      total ad  
    count   263.000000  263.000000    263.000000  
    mean      0.047470    9.695817   7386.359312  
    std       0.054685    3.639093  14280.852135  
    min       0.000971    3.000000      6.000000  
    25%       0.014655    7.000000      6.000000  
    50%       0.029181   10.000000      6.000000  
    75%       0.053633   13.000000   9691.400000  
    max       0.270477   15.000000  70489.200000  
    
    [8 rows x 66 columns]
    Index([u'BrandName', u'Brand ID', u'Year', u'Absolut', u'Aristocrat',
           u'Barton', u'Belvedere', u'Burnett', u'Chopin', u'Crystal Palac',
           u'Finlandia', u'Fleischmann's', u'Fris', u'Gilbey's', u'Gordon's',
           u'Grey Goose', u'Kamchatka', u'Ketel One', u'Level', u'McCormick',
           u'Polar Ice', u'Popov', u'Pravda', u'Seagram's', u'Skol', u'Sky',
           u'Smirnoff', u'Stolicnaya', u'Tanqueray', u'Three Olives',
           u'TotalSales', u'LagTotalSales', u'2LagTotalSales', u'LnSales',
           u'LnLSales', u'Ln2Lsales', u'LnDiff', u'diff', u'IfDom', u'DollarSales',
           u'PriceRerUnit', u'LagPrice', u'LnPrice', u'LnLPrice', u'Mag', u'News',
           u'Outdoor', u'Broad', u'Print', u'LnMag', u'LnNews', u'LnOut',
           u'LnBroad', u'LnPrint', u'Tier1', u'Tier2', u'TotalMinusSales',
           u'LagTotalMinusSales', u'TierSales', u'OutsideTierSales',
           u'LagTierSales', u'LagOutsideTierSales', u'Firstintro', u'Marketshare',
           u'LagMktshare', u'YearID', u'total ad'],
          dtype='object')


We can infer that there are a lot of columns consisting of sales ,different modes of advertising and some other variables that are not presently of our interest.


```python
print data['BrandName'].unique()
print '\n'
print 'Total Number of brands',len(data['BrandName'].unique())
```

    [u'Absolut' u'Aristocrat' u'Barton' u'Belvedere' u'Burnett' u'Chopin'
     u'Crystal Palac' u'Finlandia' u"Fleischmann's" u'Fris' u"Gilbey's"
     u"Gordon's" u'Grey Goose' u'Kamchatka' u'Ketel One' u'Level' u'McCormick'
     u'Polar Ice' u'Popov' u'Pravda' u"Seagram's" u'Skol' u'Sky' u'Smirnoff'
     u'Stolicnaya' u'Tanqueray' u'Three Olives']
    
    
    Total Number of brands 27


> This data set includes a total of 27 brands of vodka manufacturing companies. For MMM, let's choose a brand and analyse the impact of Price on sales.
  For instance, let's choose 'Absolut' as the brand for our analysis.


```python
Absolut = data[data['BrandName'] == 'Absolut']
Absolut
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>BrandName</th>
      <th>Brand ID</th>
      <th>Year</th>
      <th>Absolut</th>
      <th>Aristocrat</th>
      <th>Barton</th>
      <th>Belvedere</th>
      <th>Burnett</th>
      <th>Chopin</th>
      <th>Crystal Palac</th>
      <th>...</th>
      <th>LagTotalMinusSales</th>
      <th>TierSales</th>
      <th>OutsideTierSales</th>
      <th>LagTierSales</th>
      <th>LagOutsideTierSales</th>
      <th>Firstintro</th>
      <th>Marketshare</th>
      <th>LagMktshare</th>
      <th>YearID</th>
      <th>total ad</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Absolut</td>
      <td>15</td>
      <td>1995</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>60903</td>
      <td>1080</td>
      <td>59760</td>
      <td>1035</td>
      <td>59868</td>
      <td>0</td>
      <td>0.133923</td>
      <td>0.124241</td>
      <td>3</td>
      <td>52343.9</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Absolut</td>
      <td>15</td>
      <td>1996</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>60840</td>
      <td>1255</td>
      <td>59277</td>
      <td>1080</td>
      <td>59760</td>
      <td>0</td>
      <td>0.142007</td>
      <td>0.133923</td>
      <td>4</td>
      <td>52297.2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Absolut</td>
      <td>15</td>
      <td>1997</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>60532</td>
      <td>1532</td>
      <td>58932</td>
      <td>1255</td>
      <td>59277</td>
      <td>0</td>
      <td>0.146758</td>
      <td>0.142007</td>
      <td>5</td>
      <td>54947.9</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Absolut</td>
      <td>15</td>
      <td>1998</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>60464</td>
      <td>1730</td>
      <td>58576</td>
      <td>1532</td>
      <td>58932</td>
      <td>0</td>
      <td>0.146106</td>
      <td>0.146758</td>
      <td>6</td>
      <td>57432.7</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Absolut</td>
      <td>15</td>
      <td>1999</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>60306</td>
      <td>2118</td>
      <td>57800</td>
      <td>1730</td>
      <td>58576</td>
      <td>0</td>
      <td>0.161284</td>
      <td>0.146106</td>
      <td>7</td>
      <td>63213.9</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Absolut</td>
      <td>15</td>
      <td>2000</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>59918</td>
      <td>2549</td>
      <td>56846</td>
      <td>2118</td>
      <td>57800</td>
      <td>0</td>
      <td>0.173368</td>
      <td>0.161284</td>
      <td>8</td>
      <td>70489.2</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Absolut</td>
      <td>15</td>
      <td>2001</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>59395</td>
      <td>3358</td>
      <td>56295</td>
      <td>2549</td>
      <td>56846</td>
      <td>0</td>
      <td>0.157546</td>
      <td>0.173368</td>
      <td>9</td>
      <td>59715.4</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Absolut</td>
      <td>15</td>
      <td>2002</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>59653</td>
      <td>4197</td>
      <td>55392</td>
      <td>3358</td>
      <td>56295</td>
      <td>0</td>
      <td>0.150425</td>
      <td>0.157546</td>
      <td>10</td>
      <td>62148.3</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Absolut</td>
      <td>15</td>
      <td>2003</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>59589</td>
      <td>4939</td>
      <td>54669</td>
      <td>4197</td>
      <td>55392</td>
      <td>0</td>
      <td>0.139245</td>
      <td>0.150425</td>
      <td>11</td>
      <td>63602.1</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Absolut</td>
      <td>15</td>
      <td>2004</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>59608</td>
      <td>5582</td>
      <td>53906</td>
      <td>4939</td>
      <td>54669</td>
      <td>0</td>
      <td>0.134353</td>
      <td>0.139245</td>
      <td>12</td>
      <td>66816.3</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Absolut</td>
      <td>15</td>
      <td>2005</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>59488</td>
      <td>6346</td>
      <td>53178</td>
      <td>5582</td>
      <td>53906</td>
      <td>0</td>
      <td>0.127440</td>
      <td>0.134353</td>
      <td>13</td>
      <td>29879.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Absolut</td>
      <td>15</td>
      <td>2006</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>59524</td>
      <td>7251</td>
      <td>52094</td>
      <td>6346</td>
      <td>53178</td>
      <td>0</td>
      <td>0.124400</td>
      <td>0.127440</td>
      <td>14</td>
      <td>41147.4</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Absolut</td>
      <td>15</td>
      <td>2007</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>59345</td>
      <td>8119</td>
      <td>51092</td>
      <td>7251</td>
      <td>52094</td>
      <td>0</td>
      <td>0.120603</td>
      <td>0.124400</td>
      <td>15</td>
      <td>40280.5</td>
    </tr>
  </tbody>
</table>
<p>13 rows × 67 columns</p>
</div>



There are a lot of columns not of our interest. Let's filter them out.


```python
Pr_Absolut = Absolut[['LnSales','LnPrice']]
```


```python
Pr_Absolut
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LnSales</th>
      <th>LnPrice</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>8.006368</td>
      <td>4.765132</td>
    </tr>
    <tr>
      <th>1</th>
      <td>8.113726</td>
      <td>4.707727</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8.143227</td>
      <td>4.707727</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.196988</td>
      <td>4.750396</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8.306472</td>
      <td>4.750397</td>
    </tr>
    <tr>
      <th>5</th>
      <td>8.434898</td>
      <td>4.800839</td>
    </tr>
    <tr>
      <th>6</th>
      <td>8.384576</td>
      <td>4.844937</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8.406261</td>
      <td>4.888373</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8.409163</td>
      <td>4.928312</td>
    </tr>
    <tr>
      <th>9</th>
      <td>8.442470</td>
      <td>4.955827</td>
    </tr>
    <tr>
      <th>10</th>
      <td>8.441607</td>
      <td>5.000585</td>
    </tr>
    <tr>
      <th>11</th>
      <td>8.486115</td>
      <td>5.022234</td>
    </tr>
    <tr>
      <th>12</th>
      <td>8.519790</td>
      <td>5.022235</td>
    </tr>
  </tbody>
</table>
</div>



> In order to find the impact of Price on sales,let's build a regression model on the dataset.
  First let's plot some graphs to understand the data points


```python
plt.scatter(Pr_Absolut['LnPrice'],Pr_Absolut['LnSales'])
plt.xlabel('Log of Price')
plt.ylabel('Log of Sales')
plt.show()
```


![png](output_35_0.png)


> We can infer that price variation is almost linear in nature with sales.


```python
import statsmodels.formula.api as sm
```


```python
result = sm.ols(formula = 'LnSales ~ LnPrice',data = Pr_Absolut).fit()
```


```python
result.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>         <td>LnSales</td>     <th>  R-squared:         </th> <td>   0.688</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.660</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   24.26</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sun, 04 Jun 2017</td> <th>  Prob (F-statistic):</th> <td>0.000453</td>
</tr>
<tr>
  <th>Time:</th>                 <td>14:19:16</td>     <th>  Log-Likelihood:    </th> <td>  13.282</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>    13</td>      <th>  AIC:               </th> <td>  -22.56</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>    11</td>      <th>  BIC:               </th> <td>  -21.43</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     1</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
      <td></td>         <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>Intercept</th> <td>    2.8367</td> <td>    1.116</td> <td>    2.543</td> <td> 0.027</td> <td>    0.381     5.292</td>
</tr>
<tr>
  <th>LnPrice</th>   <td>    1.1310</td> <td>    0.230</td> <td>    4.926</td> <td> 0.000</td> <td>    0.626     1.636</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 4.580</td> <th>  Durbin-Watson:     </th> <td>   0.653</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.101</td> <th>  Jarque-Bera (JB):  </th> <td>   1.653</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.553</td> <th>  Prob(JB):          </th> <td>   0.438</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 4.352</td> <th>  Cond. No.          </th> <td>    215.</td>
</tr>
</table>



##### Here, the p-value of the price is zero that indicates that price is significant indicator of sales.

Here, the value of R-squared is 0.688 i.e the price variable indicates nearly 69% of the data points.
The co-efficient of price tells that for every unit increase in price, there is 1.13 times increase in sales.

Let's add more variables to the regression and see what happens with the R-squared.

##### Now let's try with the advertising and price column.


```python
Ad_Absolut = Absolut[['LnSales','LnMag','LnNews','LnOut','LnBroad','LnPrint','LnPrice']]
```


```python
result_ad = sm.ols('LnSales ~ LnMag + LnNews + LnOut + LnBroad + LnPrint + LnPrice',data=Ad_Absolut).fit()
```


```python
result_ad.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>         <td>LnSales</td>     <th>  R-squared:         </th> <td>   0.933</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.866</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   13.96</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sun, 04 Jun 2017</td> <th>  Prob (F-statistic):</th>  <td>0.00270</td>
</tr>
<tr>
  <th>Time:</th>                 <td>14:28:55</td>     <th>  Log-Likelihood:    </th> <td>  23.293</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>    13</td>      <th>  AIC:               </th> <td>  -32.59</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>     6</td>      <th>  BIC:               </th> <td>  -28.63</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     6</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
      <td></td>         <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>Intercept</th> <td>    1.6613</td> <td>    1.697</td> <td>    0.979</td> <td> 0.365</td> <td>   -2.491     5.814</td>
</tr>
<tr>
  <th>LnMag</th>     <td>    0.0891</td> <td>    0.062</td> <td>    1.438</td> <td> 0.200</td> <td>   -0.062     0.241</td>
</tr>
<tr>
  <th>LnNews</th>    <td>    0.0131</td> <td>    0.012</td> <td>    1.132</td> <td> 0.301</td> <td>   -0.015     0.042</td>
</tr>
<tr>
  <th>LnOut</th>     <td>   -0.1219</td> <td>    0.106</td> <td>   -1.152</td> <td> 0.293</td> <td>   -0.381     0.137</td>
</tr>
<tr>
  <th>LnBroad</th>   <td>    0.0328</td> <td>    0.023</td> <td>    1.413</td> <td> 0.207</td> <td>   -0.024     0.090</td>
</tr>
<tr>
  <th>LnPrint</th>   <td>    0.1101</td> <td>    0.081</td> <td>    1.366</td> <td> 0.221</td> <td>   -0.087     0.307</td>
</tr>
<tr>
  <th>LnPrice</th>   <td>    1.0968</td> <td>    0.253</td> <td>    4.332</td> <td> 0.005</td> <td>    0.477     1.716</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 0.747</td> <th>  Durbin-Watson:     </th> <td>   1.648</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.688</td> <th>  Jarque-Bera (JB):  </th> <td>   0.610</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 0.043</td> <th>  Prob(JB):          </th> <td>   0.737</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 1.942</td> <th>  Cond. No.          </th> <td>1.83e+03</td>
</tr>
</table>



The R-squared value has increased!.The model is able to explain 87% of the data points. But here the p-values of some variables are high which can be accounted due to interaction effect and some other factors.

Let's try out the interation effect method between variables broad and print


```python
result_inter = sm.ols('LnSales ~ LnMag + LnNews + LnOut + LnBroad * LnPrint + LnPrice',data=Ad_Absolut).fit()
```


```python
result_inter.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>         <td>LnSales</td>     <th>  R-squared:         </th> <td>   0.972</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.933</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   24.84</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sun, 04 Jun 2017</td> <th>  Prob (F-statistic):</th>  <td>0.00135</td>
</tr>
<tr>
  <th>Time:</th>                 <td>14:54:03</td>     <th>  Log-Likelihood:    </th> <td>  28.963</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>    13</td>      <th>  AIC:               </th> <td>  -41.93</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>     5</td>      <th>  BIC:               </th> <td>  -37.41</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     7</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
         <td></td>            <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>Intercept</th>       <td>   -8.2128</td> <td>    3.931</td> <td>   -2.089</td> <td> 0.091</td> <td>  -18.317     1.892</td>
</tr>
<tr>
  <th>LnMag</th>           <td>   -0.0110</td> <td>    0.058</td> <td>   -0.190</td> <td> 0.857</td> <td>   -0.160     0.138</td>
</tr>
<tr>
  <th>LnNews</th>          <td>   -0.0056</td> <td>    0.011</td> <td>   -0.515</td> <td> 0.628</td> <td>   -0.034     0.022</td>
</tr>
<tr>
  <th>LnOut</th>           <td>    0.0426</td> <td>    0.097</td> <td>    0.437</td> <td> 0.680</td> <td>   -0.208     0.293</td>
</tr>
<tr>
  <th>LnBroad</th>         <td>    1.6251</td> <td>    0.604</td> <td>    2.692</td> <td> 0.043</td> <td>    0.073     3.177</td>
</tr>
<tr>
  <th>LnPrint</th>         <td>    1.2719</td> <td>    0.444</td> <td>    2.864</td> <td> 0.035</td> <td>    0.130     2.413</td>
</tr>
<tr>
  <th>LnBroad:LnPrint</th> <td>   -0.1586</td> <td>    0.060</td> <td>   -2.638</td> <td> 0.046</td> <td>   -0.313    -0.004</td>
</tr>
<tr>
  <th>LnPrice</th>         <td>    0.6901</td> <td>    0.236</td> <td>    2.919</td> <td> 0.033</td> <td>    0.082     1.298</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 1.382</td> <th>  Durbin-Watson:     </th> <td>   1.615</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.501</td> <th>  Jarque-Bera (JB):  </th> <td>   0.165</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.211</td> <th>  Prob(JB):          </th> <td>   0.921</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 3.355</td> <th>  Cond. No.          </th> <td>1.94e+04</td>
</tr>
</table>



Boom! The results here are surprised. The presence of significant interaction indicates that the effect of one predictor variable on the response variable is different at different values of the other predictor variable.
    Therefore,the individial effects of the predictors also include the effects of the co-efficients of the interaction terms.
    The R-squared value has also increased indicating the model can explain most of the data points now.


```python

```
